﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_distance_text_text_img = ''
        let normal_humidity_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_temperature_current_text_img = ''
        let normal_temperature_current_separator_img = ''
        let normal_digital_clock_img_time = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time = ''
        let Button_1 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'bg_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: 'bt_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 254,
              month_startY: 376,
              month_sc_array: ["number_0.png","number_1.png","number_2.png","number_3.png","number_4.png","number_5.png","number_6.png","number_7.png","number_8.png","number_9.png"],
              month_tc_array: ["number_0.png","number_1.png","number_2.png","number_3.png","number_4.png","number_5.png","number_6.png","number_7.png","number_8.png","number_9.png"],
              month_en_array: ["number_0.png","number_1.png","number_2.png","number_3.png","number_4.png","number_5.png","number_6.png","number_7.png","number_8.png","number_9.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 213,
              day_startY: 376,
              day_sc_array: ["number_0.png","number_1.png","number_2.png","number_3.png","number_4.png","number_5.png","number_6.png","number_7.png","number_8.png","number_9.png"],
              day_tc_array: ["number_0.png","number_1.png","number_2.png","number_3.png","number_4.png","number_5.png","number_6.png","number_7.png","number_8.png","number_9.png"],
              day_en_array: ["number_0.png","number_1.png","number_2.png","number_3.png","number_4.png","number_5.png","number_6.png","number_7.png","number_8.png","number_9.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'number_tchk.png',
              day_unit_tc: 'number_tchk.png',
              day_unit_en: 'number_tchk.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 168,
              y: 376,
              week_en: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_tc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_sc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 130,
              y: 294,
              font_array: ["number_0.png","number_1.png","number_2.png","number_3.png","number_4.png","number_5.png","number_6.png","number_7.png","number_8.png","number_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'number_tchk.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 51,
              y: 295,
              src: 'icon_humidity.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 328,
              y: 118,
              font_array: ["number_0.png","number_1.png","number_2.png","number_3.png","number_4.png","number_5.png","number_6.png","number_7.png","number_8.png","number_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 230,
              y: 119,
              src: 'icon_puls.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 124,
              y: 119,
              font_array: ["number_0.png","number_1.png","number_2.png","number_3.png","number_4.png","number_5.png","number_6.png","number_7.png","number_8.png","number_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 57,
              y: 123,
              src: 'icon_steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 321,
              y: 293,
              font_array: ["number_0.png","number_1.png","number_2.png","number_3.png","number_4.png","number_5.png","number_6.png","number_7.png","number_8.png","number_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 251,
              y: 296,
              src: 'icon_batt.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 224,
              y: 38,
              font_array: ["number_0.png","number_1.png","number_2.png","number_3.png","number_4.png","number_5.png","number_6.png","number_7.png","number_8.png","number_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'number_gradus.png',
              unit_tc: 'number_gradus.png',
              unit_en: 'number_gradus.png',
              negative_image: 'number_minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 161,
              y: 38,
              src: 'icon_temp.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 66,
              hour_startY: 152,
              hour_array: ["T_0.png","T_1.png","T_2.png","T_3.png","T_4.png","T_5.png","T_6.png","T_7.png","T_8.png","T_9.png"],
              hour_zero: 1,
              hour_space: -5,
              hour_angle: 0,
              hour_unit_sc: 'T_tchk.png',
              hour_unit_tc: 'T_tchk.png',
              hour_unit_en: 'T_tchk.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["T_0.png","T_1.png","T_2.png","T_3.png","T_4.png","T_5.png","T_6.png","T_7.png","T_8.png","T_9.png"],
              minute_zero: 1,
              minute_space: -5,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 189,
              day_startY: 376,
              day_sc_array: ["number_0.png","number_1.png","number_2.png","number_3.png","number_4.png","number_5.png","number_6.png","number_7.png","number_8.png","number_9.png"],
              day_tc_array: ["number_0.png","number_1.png","number_2.png","number_3.png","number_4.png","number_5.png","number_6.png","number_7.png","number_8.png","number_9.png"],
              day_en_array: ["number_0.png","number_1.png","number_2.png","number_3.png","number_4.png","number_5.png","number_6.png","number_7.png","number_8.png","number_9.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'number_tchk.png',
              day_unit_tc: 'number_tchk.png',
              day_unit_en: 'number_tchk.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 228,
              y: 376,
              week_en: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_tc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_sc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 66,
              hour_startY: 152,
              hour_array: ["T_0.png","T_1.png","T_2.png","T_3.png","T_4.png","T_5.png","T_6.png","T_7.png","T_8.png","T_9.png"],
              hour_zero: 1,
              hour_space: -5,
              hour_angle: 0,
              hour_unit_sc: 'T_tchk.png',
              hour_unit_tc: 'T_tchk.png',
              hour_unit_en: 'T_tchk.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["T_0.png","T_1.png","T_2.png","T_3.png","T_4.png","T_5.png","T_6.png","T_7.png","T_8.png","T_9.png"],
              minute_zero: 1,
              minute_space: -5,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 166,
              y: 374,
              w: 127,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}